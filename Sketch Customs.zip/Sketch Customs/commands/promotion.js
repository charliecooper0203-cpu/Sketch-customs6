const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const crypto = require('crypto');

const promotionRecords = new Map();

module.exports = {
  promotionRecords,
  data: new SlashCommandBuilder()
    .setName('promotion')
    .setDescription('Create a promotion record')
    .addUserOption((option) =>
      option
        .setName('staff')
        .setDescription('The staff member receiving the promotion')
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName('reason')
        .setDescription('The reason for the promotion')
        .setRequired(false)
    )
    .addUserOption((option) =>
      option
        .setName('issued_by')
        .setDescription('The staff member issuing the promotion')
        .setRequired(false)
    ),

  async execute(interaction) {
    const staff = interaction.options.getUser('staff');
    const reason = interaction.options.getString('reason') || 'Active';
    const issuer = interaction.options.getUser('issued_by') || interaction.user;
    const recordId = `REC-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;
    const date = new Date();
    const formattedTime = date.toLocaleString('en-GB', {
      weekday: 'long',
      day: '2-digit',
      month: 'long',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      timeZone: 'Europe/London',
    });

    promotionRecords.set(recordId, {
      id: recordId,
      staffId: staff.id,
      staffName: staff.username,
      reason,
      issuedBy: issuer.id,
      date: formattedTime,
      active: true,
    });

    const userRecords = [...promotionRecords.values()].filter((record) => record.staffId === staff.id);
    const total = userRecords.length;
    const active = userRecords.filter((record) => record.active).length;

    const embed = new EmbedBuilder()
      .setTitle('<:IMG_0187:1527402599588827269> Promotion')
      .setColor(0x36393f)
      .addFields(
        { name: 'Staff:', value: `${staff} (\`${staff.username}\`)`, inline: false },
        { name: 'Reason:', value: reason, inline: false },
        { name: 'Issued By:', value: `${issuer}`, inline: false },
        { name: 'Date:', value: `\`${formattedTime}\``, inline: false },
        { name: 'Record ID:', value: `\`${recordId}\``, inline: false },
        { name: 'Record:', value: `${active} active / ${total} total`, inline: false },
        {
          name: '<:IMG_0187:1527402599588827269> Sketch Customs Staff Management',
          value: '\u200b',
          inline: false,
        }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
