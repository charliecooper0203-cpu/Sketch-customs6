const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { promotionRecords } = require('./promotion');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('promotion-revoke')
    .setDescription('Revoke a promotion using its Record ID')
    .addStringOption((option) =>
      option
        .setName('id')
        .setDescription('The promotion Record ID')
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName('reason')
        .setDescription('Reason for revoking the promotion')
        .setRequired(true)
    ),

  async execute(interaction) {
    const recordId = interaction.options.getString('id').toUpperCase();
    const reason = interaction.options.getString('reason');
    const record = promotionRecords.get(recordId);

    if (!record) {
      return interaction.reply({
        content: `❌ No promotion record was found with ID \`${recordId}\`.`,
        ephemeral: true,
      });
    }

    if (!record.active) {
      return interaction.reply({
        content: `❌ Promotion \`${recordId}\` has already been revoked.`,
        ephemeral: true,
      });
    }

    record.active = false;
    record.revokedBy = interaction.user.id;
    record.revokeReason = reason;
    record.revokedAt = new Date();

    const userRecords = [...promotionRecords.values()].filter((promotion) => promotion.staffId === record.staffId);
    const total = userRecords.length;
    const active = userRecords.filter((promotion) => promotion.active).length;

    const embed = new EmbedBuilder()
      .setTitle('<:IMG_0187:1527402599588827269> Promotion Revoked')
      .setColor(0xed4245)
      .addFields(
        { name: 'Staff:', value: `<@${record.staffId}>`, inline: false },
        { name: 'Original Reason:', value: record.reason, inline: false },
        { name: 'Revoked By:', value: `${interaction.user}`, inline: false },
        { name: 'Revoke Reason:', value: reason, inline: false },
        { name: 'Original Date:', value: `\`${record.date}\``, inline: false },
        { name: 'Record ID:', value: `\`${recordId}\``, inline: false },
        { name: 'Record:', value: `${active} active / ${total} total`, inline: false },
        {
          name: '<:IMG_0187:1527402599588827269> Sketch Customs Staff Management',
          value: 'The promotion has been revoked.',
          inline: false,
        }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
