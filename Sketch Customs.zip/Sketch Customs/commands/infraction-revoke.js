const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const { infractionRecords } = require('./infraction');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('infraction-revoke')
    .setDescription('Revoke an infraction using its Record ID')
    .addStringOption((option) =>
      option
        .setName('id')
        .setDescription('The infraction Record ID')
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName('reason')
        .setDescription('Reason for revoking the infraction')
        .setRequired(true)
    ),

  async execute(interaction) {
    const recordId = interaction.options.getString('id').toUpperCase();
    const revokeReason = interaction.options.getString('reason');
    const record = infractionRecords.get(recordId);

    if (!record) {
      return interaction.reply({
        content: `❌ No infraction record was found with ID \`${recordId}\`.`,
        ephemeral: true,
      });
    }

    if (!record.active) {
      return interaction.reply({
        content: `❌ Infraction \`${recordId}\` has already been revoked.`,
        ephemeral: true,
      });
    }

    record.active = false;
    record.revokedBy = interaction.user.id;
    record.revokeReason = revokeReason;
    record.revokedAt = new Date();

    const userRecords = [...infractionRecords.values()].filter((infraction) => infraction.staffId === record.staffId);
    const total = userRecords.length;
    const active = userRecords.filter((infraction) => infraction.active).length;

    const embed = new EmbedBuilder()
      .setTitle('<:IMG_0187:1527402599588827269> Infraction Revoked')
      .setColor(0xed4245)
      .addFields(
        { name: 'Staff:', value: `<@${record.staffId}>`, inline: false },
        { name: 'Original Infraction:', value: record.reason, inline: false },
        { name: 'Revoked By:', value: `${interaction.user}`, inline: false },
        { name: 'Revoke Reason:', value: revokeReason, inline: false },
        { name: 'Original Date:', value: `\`${record.date}\``, inline: false },
        { name: 'Record ID:', value: `\`${recordId}\``, inline: false },
        { name: 'Record:', value: `${active} active / ${total} total`, inline: false },
        {
          name: '<:IMG_0187:1527402599588827269> Sketch Customs Staff Management',
          value: 'The infraction has been revoked.',
          inline: false,
        }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
