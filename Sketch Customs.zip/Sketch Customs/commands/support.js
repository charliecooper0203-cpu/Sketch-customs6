const {
  SlashCommandBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionFlagsBits,
} = require('discord.js');

const GENERAL_SUPPORT_ROLE_ID = '1539314314970796143';
const STAFF_REPORT_ROLE_ID = '1539314150671392849';
const HIGHRANK_SUPPORT_ROLE_ID = '1539313544086954145';

const TICKET_CONFIG = {
  general_support: { name: 'general-support', title: '🛠️ General Support', roleId: GENERAL_SUPPORT_ROLE_ID },
  staff_report: { name: 'staff-report', title: '🚨 Report a Staff Member', roleId: STAFF_REPORT_ROLE_ID },
  highrank_support: { name: 'highrank-support', title: '👑 Highrank Support', roleId: HIGHRANK_SUPPORT_ROLE_ID },
};

module.exports = {
  data: new SlashCommandBuilder()
    .setName('support')
    .setDescription('Send the support ticket panel'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle('🎫 Support Tickets')
      .setDescription(
        'Need help? Select the type of ticket you would like to create below.\n\n' +
          '🛠️ **General Support**\n' +
          'Get help with a general question or issue.\n\n' +
          '🚨 **Report a Staff Member**\n' +
          'Report a member of staff.\n\n' +
          '👑 **Highrank Support**\n' +
          'Speak with a high-ranking member of staff.'
      )
      .setColor('Blue')
      .setFooter({ text: 'Please select the correct ticket type.' });

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('support_ticket')
      .setPlaceholder('Select a ticket type...')
      .addOptions(
        new StringSelectMenuOptionBuilder()
          .setLabel('General Support')
          .setDescription('Get help with a general issue.')
          .setEmoji('🛠️')
          .setValue('general_support'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Report a Staff Member')
          .setDescription('Report a member of staff.')
          .setEmoji('🚨')
          .setValue('staff_report'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Highrank Support')
          .setDescription('Speak with a high-ranking member.')
          .setEmoji('👑')
          .setValue('highrank_support')
      );

    const row = new ActionRowBuilder().addComponents(selectMenu);

    await interaction.channel.send({ embeds: [embed], components: [row] });
    await interaction.reply({ content: '✅ Support ticket panel sent!', ephemeral: true });
  },

  async handleInteraction(interaction) {
    if (interaction.isStringSelectMenu() && interaction.customId === 'support_ticket') {
      const ticketType = interaction.values[0];
      const config = TICKET_CONFIG[ticketType];

      if (!config) {
        return interaction.reply({ content: '❌ Invalid ticket type.', ephemeral: true });
      }

      const existingTicket = interaction.guild.channels.cache.find(
        (channel) => channel.topic === `Ticket Owner: ${interaction.user.id}`
      );

      if (existingTicket) {
        return interaction.reply({
          content: `❌ You already have an open ticket: ${existingTicket}`,
          ephemeral: true,
        });
      }

      const ticketChannel = await interaction.guild.channels.create({
        name: `${config.name}-${interaction.user.username}`,
        type: ChannelType.GuildText,
        topic: `Ticket Owner: ${interaction.user.id}`,
        permissionOverwrites: [
          { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
          {
            id: interaction.user.id,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory,
              PermissionFlagsBits.AttachFiles,
            ],
          },
          {
            id: config.roleId,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory,
              PermissionFlagsBits.ManageMessages,
            ],
          },
        ],
      });

      const welcomeEmbed = new EmbedBuilder()
        .setTitle(config.title)
        .setDescription(
          `Welcome ${interaction.user}!\n\n` +
            `Thank you for contacting our support team.\n\n` +
            `Please explain your issue in as much detail as possible. A member of the appropriate support team will assist you shortly.\n\n` +
            `**Ticket Information**\n` +
            `> **User:** ${interaction.user}\n` +
            `> **Ticket Type:** ${config.title}\n` +
            `> **Status:** 🟢 Open\n` +
            `> **Claimed By:** Nobody`
        )
        .setColor('Blue')
        .setFooter({ text: 'Support Ticket System' })
        .setTimestamp();

      const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('claim_ticket').setLabel('Claim Ticket').setEmoji('📌').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('close_ticket').setLabel('Close Ticket').setEmoji('🔒').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('add_note').setLabel('Add Note').setEmoji('📝').setStyle(ButtonStyle.Secondary)
      );

      await ticketChannel.send({ content: `${interaction.user} <@&${config.roleId}>`, embeds: [welcomeEmbed], components: [buttons] });
      await interaction.reply({ content: `🎫 **Your ticket has been created!**\n\n**Ticket:** ${ticketChannel}\n**Type:** ${config.title}`, ephemeral: true });
      return;
    }

    if (interaction.isButton()) {
      if (interaction.customId === 'claim_ticket') {
        const hasPermission = interaction.member.roles.cache.some(
          (role) =>
            role.id === GENERAL_SUPPORT_ROLE_ID ||
            role.id === STAFF_REPORT_ROLE_ID ||
            role.id === HIGHRANK_SUPPORT_ROLE_ID
        );

        if (!hasPermission) {
          return interaction.reply({ content: '❌ You do not have permission to claim tickets.', ephemeral: true });
        }

        const claimEmbed = new EmbedBuilder()
          .setTitle('📌 Ticket Claimed')
          .setDescription(`This ticket has been claimed by ${interaction.user}.\n\nThey will now handle this ticket.`)
          .setColor('Green')
          .setTimestamp();

        await interaction.channel.send({ embeds: [claimEmbed] });
        await interaction.reply({ content: '✅ You have claimed this ticket.', ephemeral: true });
        return;
      }

      if (interaction.customId === 'close_ticket') {
        const hasPermission = interaction.member.roles.cache.some(
          (role) =>
            role.id === GENERAL_SUPPORT_ROLE_ID ||
            role.id === STAFF_REPORT_ROLE_ID ||
            role.id === HIGHRANK_SUPPORT_ROLE_ID
        );

        if (!hasPermission) {
          return interaction.reply({ content: '❌ You do not have permission to close tickets.', ephemeral: true });
        }

        await interaction.reply({ content: '🔒 This ticket will be closed in 5 seconds.' });

        setTimeout(async () => {
          try {
            await interaction.channel.delete();
          } catch (error) {
            console.log('Could not delete ticket:', error);
          }
        }, 5000);
        return;
      }

      if (interaction.customId === 'add_note') {
        const hasPermission = interaction.member.roles.cache.some(
          (role) =>
            role.id === GENERAL_SUPPORT_ROLE_ID ||
            role.id === STAFF_REPORT_ROLE_ID ||
            role.id === HIGHRANK_SUPPORT_ROLE_ID
        );

        if (!hasPermission) {
          return interaction.reply({ content: '❌ You do not have permission to add notes.', ephemeral: true });
        }

        const modal = new ModalBuilder().setCustomId('ticket_note').setTitle('📝 Add Ticket Note');
        const noteInput = new TextInputBuilder()
          .setCustomId('note')
          .setLabel('Ticket Note')
          .setPlaceholder('Enter your note here...')
          .setStyle(TextInputStyle.Paragraph)
          .setRequired(true);

        const row = new ActionRowBuilder().addComponents(noteInput);
        modal.addComponents(row);
        await interaction.showModal(modal);
        return;
      }
    }

    if (interaction.isModalSubmit() && interaction.customId === 'ticket_note') {
      const note = interaction.fields.getTextInputValue('note');
      const noteEmbed = new EmbedBuilder()
        .setTitle('📝 Staff Note')
        .setDescription(note)
        .addFields({ name: 'Added By', value: `${interaction.user}`, inline: true })
        .setColor('Yellow')
        .setTimestamp();

      await interaction.reply({ embeds: [noteEmbed] });
      return;
    }
  },
};
