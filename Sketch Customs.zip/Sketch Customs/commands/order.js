const {
  SlashCommandBuilder,
  ActionRowBuilder,
  StringSelectMenuBuilder,
  StringSelectMenuOptionBuilder,
  EmbedBuilder,
  ButtonBuilder,
  ButtonStyle,
  ChannelType,
  PermissionFlagsBits,
} = require('discord.js');

const ORDER_STAFF_ROLE_ID = '1539313544086954145';

module.exports = {
  data: new SlashCommandBuilder()
    .setName('order')
    .setDescription('Send the order panel'),

  async execute(interaction) {
    const embed = new EmbedBuilder()
      .setTitle('🛒 Orders')
      .setDescription(
        'Looking to order a design? Click the button below to get started.\n\n' +
          '**Available Services**\n' +
          '🚗 Vehicle Livery\n' +
          '👕 Uniform\n' +
          '🖥️ Server Branding\n' +
          '🚨 ELS Design\n' +
          '📋 Embeds\n' +
          '🎨 Other Design'
      )
      .setColor('Blue')
      .setFooter({ text: 'Click the button below to place an order.' });

    const button = new ActionRowBuilder().addComponents(
      new ButtonBuilder().setCustomId('place_order').setLabel('Place an Order').setEmoji('🛒').setStyle(ButtonStyle.Primary)
    );

    await interaction.channel.send({ embeds: [embed], components: [button] });
    await interaction.reply({ content: '✅ Order panel sent!', ephemeral: true });
  },

  async handleInteraction(interaction) {
    if (interaction.isButton() && interaction.customId === 'place_order') {
      const selectMenu = new StringSelectMenuBuilder()
        .setCustomId('order_type')
        .setPlaceholder('Select what you would like to order...')
        .addOptions(
          new StringSelectMenuOptionBuilder().setLabel('Vehicle Livery').setDescription('Order a vehicle livery design.').setEmoji('🚗').setValue('vehicle_livery'),
          new StringSelectMenuOptionBuilder().setLabel('Uniform').setDescription('Order a Roblox uniform design.').setEmoji('👕').setValue('uniform'),
          new StringSelectMenuOptionBuilder().setLabel('Server Branding').setDescription('Order Discord server branding.').setEmoji('🖥️').setValue('server_branding'),
          new StringSelectMenuOptionBuilder().setLabel('ELS Design').setDescription('Order an ELS design.').setEmoji('🚨').setValue('els_design'),
          new StringSelectMenuOptionBuilder().setLabel('Embeds').setDescription('Order custom Discord embeds.').setEmoji('📋').setValue('embeds'),
          new StringSelectMenuOptionBuilder().setLabel('Other Design').setDescription('Order another type of design.').setEmoji('🎨').setValue('other_design')
        );

      const row = new ActionRowBuilder().addComponents(selectMenu);
      await interaction.reply({
        content: '🛒 **Place an Order**\n\nPlease select what you would like to order from the menu below.',
        components: [row],
        ephemeral: true,
      });
      return;
    }

    if (interaction.isStringSelectMenu() && interaction.customId === 'order_type') {
      const orderType = interaction.values[0];
      const orderNames = {
        vehicle_livery: 'Vehicle Livery',
        uniform: 'Uniform',
        server_branding: 'Server Branding',
        els_design: 'ELS Design',
        embeds: 'Embeds',
        other_design: 'Other Design',
      };

      const orderName = orderNames[orderType];
      if (!orderName) {
        return interaction.reply({ content: '❌ Invalid order type.', ephemeral: true });
      }

      const existingOrder = interaction.guild.channels.cache.find(
        (channel) => channel.topic === `Order Owner: ${interaction.user.id}`
      );

      if (existingOrder) {
        return interaction.reply({
          content: `❌ You already have an open order: ${existingOrder}`,
          ephemeral: true,
        });
      }

      const orderChannel = await interaction.guild.channels.create({
        name: `order-${interaction.user.username}`,
        type: ChannelType.GuildText,
        topic: `Order Owner: ${interaction.user.id}`,
        permissionOverwrites: [
          { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
          {
            id: interaction.user.id,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory,
              PermissionFlagsBits.AttachFiles,
            ],
          },
          {
            id: ORDER_STAFF_ROLE_ID,
            allow: [
              PermissionFlagsBits.ViewChannel,
              PermissionFlagsBits.SendMessages,
              PermissionFlagsBits.ReadMessageHistory,
              PermissionFlagsBits.ManageMessages,
            ],
          },
        ],
      });

      const orderEmbed = new EmbedBuilder()
        .setTitle(`🛒 ${orderName} Order`)
        .setDescription(
          `Welcome ${interaction.user}!\n\n` +
            `Thank you for placing an order with us.\n\n` +
            `Please provide as much information as possible about what you would like designed.\n\n` +
            `**Order Information**\n` +
            `> **Customer:** ${interaction.user}\n` +
            `> **Order Type:** ${orderName}\n` +
            `> **Status:** 🟢 Open\n` +
            `> **Designer:** Not Claimed`
        )
        .setColor('Blue')
        .setFooter({ text: 'Order System' })
        .setTimestamp();

      const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('claim_order').setLabel('Claim Order').setEmoji('📌').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('close_order').setLabel('Close Order').setEmoji('🔒').setStyle(ButtonStyle.Danger)
      );

      await orderChannel.send({ content: `${interaction.user} <@&${ORDER_STAFF_ROLE_ID}>`, embeds: [orderEmbed], components: [buttons] });
      await interaction.reply({ content: `🎫 **Your order has been created!**\n\n**Order:** ${orderChannel}\n**Type:** ${orderName}`, ephemeral: true });
    }
  },
};
