const {
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('giveaway')
    .setDescription('Create a giveaway')
    .addStringOption((option) =>
      option
        .setName('prize')
        .setDescription('The prize being given away')
        .setRequired(true)
    )
    .addStringOption((option) =>
      option
        .setName('duration')
        .setDescription('Giveaway duration, e.g. 10m, 2h, 3d')
        .setRequired(true)
    )
    .addIntegerOption((option) =>
      option
        .setName('winners')
        .setDescription('Number of winners')
        .setRequired(true)
        .setMinValue(1)
    ),

  async execute(interaction) {
    const prize = interaction.options.getString('prize');
    const duration = interaction.options.getString('duration');
    const winners = interaction.options.getInteger('winners');

    const match = duration.toLowerCase().match(/^([0-9]+)(s|m|h|d|w)$/);
    if (!match) {
      return interaction.reply({
        content:
          '❌ Invalid duration.\n\n' +
          '**Use one of the following:**\n' +
          '• `30s` - 30 seconds\n' +
          '• `10m` - 10 minutes\n' +
          '• `2h` - 2 hours\n' +
          '• `3d` - 3 days\n' +
          '• `1w` - 1 week',
        ephemeral: true,
      });
    }

    const amount = Number.parseInt(match[1], 10);
    const unit = match[2];
    const multipliers = { s: 1, m: 60, h: 3600, d: 86400, w: 604800 };
    const durationSeconds = amount * multipliers[unit];
    const giveawayId = Math.random().toString(36).substring(2, 8).toUpperCase();
    const participants = new Set();

    const countButton = new ButtonBuilder()
      .setCustomId(`giveaway_count_${giveawayId}`)
      .setLabel('0')
      .setEmoji('👥')
      .setStyle(ButtonStyle.Secondary)
      .setDisabled(true);

    const enterButton = new ButtonBuilder()
      .setCustomId(`giveaway_enter_${giveawayId}`)
      .setLabel('Enter Giveaway')
      .setEmoji('🎟️')
      .setStyle(ButtonStyle.Primary);

    const row = new ActionRowBuilder().addComponents(countButton, enterButton);

    const endTimestamp = Math.floor((Date.now() + durationSeconds * 1000) / 1000);

    const giveawayEmbed = new EmbedBuilder()
      .setTitle(`🎉 ${prize}`)
      .setColor(0x36393f)
      .addFields(
        { name: 'Hosted by:', value: `${interaction.user} | ID: \`${giveawayId}\``, inline: false },
        { name: '🎁 Prize:', value: `**${prize}**`, inline: false },
        { name: '👥 Winners:', value: `${winners}`, inline: false },
        { name: '⏰ Ends:', value: `<t:${endTimestamp}:R>`, inline: false },
        {
          name: '📋 Requirements:',
          value: 'Click the **Enter Giveaway** button below to participate.',
          inline: false,
        }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [giveawayEmbed], components: [row] });
    const giveawayMessage = await interaction.fetchReply();

    const collector = giveawayMessage.createMessageComponentCollector({
      time: durationSeconds * 1000,
    });

    collector.on('collect', async (buttonInteraction) => {
      if (buttonInteraction.customId !== `giveaway_enter_${giveawayId}`) return;

      if (participants.has(buttonInteraction.user.id)) {
        return buttonInteraction.reply({
          content: '❌ You have already entered this giveaway.',
          ephemeral: true,
        });
      }

      participants.add(buttonInteraction.user.id);
      countButton.setLabel(String(participants.size));

      await buttonInteraction.update({ components: [row] });
      await buttonInteraction.followUp({
        content: '🎉 You have entered the giveaway!',
        ephemeral: true,
      });
    });

    collector.on('end', async () => {
      const participantList = [...participants];
      const selectedWinners = [];
      const winnerAmount = Math.min(winners, participantList.length);

      while (selectedWinners.length < winnerAmount) {
        const randomIndex = Math.floor(Math.random() * participantList.length);
        const userId = participantList[randomIndex];

        if (!selectedWinners.includes(userId)) {
          selectedWinners.push(userId);
        }
      }

      let winnerText = 'No winners — nobody entered the giveaway.';
      if (selectedWinners.length > 0) {
        winnerText = selectedWinners
          .map((userId, index) => `${index + 1}. <@${userId}>`)
          .join('\n');
      }

      const finalEmbed = new EmbedBuilder()
        .setTitle(`🎉 ${prize}`)
        .setColor(0x36393f)
        .addFields(
          { name: 'Hosted by:', value: `${interaction.user} | ID: \`${giveawayId}\``, inline: false },
          { name: '🎁 Prize:', value: `**${prize}**`, inline: false },
          { name: '👥 Winners:', value: `${winners}`, inline: false },
          { name: '🎉 Winners:', value: winnerText, inline: false },
          { name: '👥 Participants:', value: `${participants.size}`, inline: false }
        )
        .setTimestamp();

      countButton.setLabel(String(participants.size));
      enterButton.setLabel('Ended').setEmoji('🔒').setStyle(ButtonStyle.Danger).setDisabled(true);

      await giveawayMessage.edit({ embeds: [finalEmbed], components: [row] });

      if (selectedWinners.length > 0) {
        const mentions = selectedWinners.map((userId) => `<@${userId}>`).join(' ');
        await interaction.channel.send(`🎉 Congratulations ${mentions}!\nYou won **${prize}**!`);
      } else {
        await interaction.channel.send('🔒 The giveaway has ended, but nobody entered.');
      }
    });
  },
};
