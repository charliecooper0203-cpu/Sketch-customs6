module.exports = {
    clientId: 'YOUR_CLIENT_ID',
    guildId: 'YOUR_SERVER_ID',
    embedColor: '#ffffff'
};